<?php

/* Database config */

$db_host		= '';
$db_user		= '';
$db_pass		= '';
$db_database	= ''; 

/* End config */

/* File directory: */

$directory='files';

?>